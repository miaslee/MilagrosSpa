package com.devmiax.spamilagros;

// Imports
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;

import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private View cardNextAppointment;
    private TextView tvNextTitle, tvNextDetail;
    private MaterialButton btnAgendarDesdeBanner;

    // Mantén referencia a la cita mostrada para abrir detalle
    private String proximaCitaId;
    private void nav(int viewId, Class<?> target) {
        View v = findViewById(viewId);
        if (v != null) v.setOnClickListener(x -> startActivity(new Intent(this, target)));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // tu layout existente  :contentReference[oaicite:1]{index=1}

        nav(R.id.btnGoToAgenda,         servicios.class);
        nav(R.id.btnGoToMyAppointments, misCitas.class);
        nav(R.id.btnGoToServicios,      servicios.class);
        nav(R.id.btnGoToPerfil,         PerfilActivity.class);
        nav(R.id.btnAgendarDesdeBanner, servicios.class); // banner opcional


        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // Bind views (IDs del XML)
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);

        cardNextAppointment   = findViewById(R.id.cardNextAppointment);
        tvNextTitle           = findViewById(R.id.tvNextTitle);
        tvNextDetail          = findViewById(R.id.tvNextDetail);
        btnAgendarDesdeBanner = findViewById(R.id.btnAgendarDesdeBanner);

        // Tocar el banner → Detalle (si hay cita cargada)
        cardNextAppointment.setOnClickListener(v -> {
            if (proximaCitaId != null) {
                Intent i = new Intent(this, DetalleCita.class);
                i.putExtra("citaId", proximaCitaId);
                startActivity(i);
            }
        });

        // CTA "Agendar ahora" → abre servicios/agenda
        btnAgendarDesdeBanner.setOnClickListener(v -> {
            startActivity(new Intent(this, servicios.class));
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        cargarProximaCita();
    }

    private void cargarProximaCita() {
        var user = auth.getCurrentUser();
        if (user == null) {
            mostrarSinProximaCita();
            return;
        }

        // --------- Estrategia A: si tus documentos de 'citas' tienen un Timestamp 'startAt' ---------
        // Recomendado: guardar 'startAt' al crear la cita (fecha+hora como Timestamp).
        Timestamp ahora = Timestamp.now();
        db.collection("citas")
                .whereEqualTo("uidCliente", user.getUid())
                .whereGreaterThanOrEqualTo("startAt", ahora) // <-- usa startAt si existe
                .orderBy("startAt", Query.Direction.ASCENDING)
                .limit(1)
                .get()
                .addOnSuccessListener(snap -> {
                    if (!snap.isEmpty()) {
                        DocumentSnapshot d = snap.getDocuments().get(0);
                        renderBannerConCita(d);
                    } else {
                        // --------- Estrategia B (fallback): sin startAt, usar fecha/hora (String) ---------
                        cargarProximaCitaSinStartAt(user.getUid());
                    }
                })
                .addOnFailureListener(e -> {
                    // Si falla (ej. índice faltante), usamos fallback
                    cargarProximaCitaSinStartAt(user.getUid());
                });
    }

    private void cargarProximaCitaSinStartAt(String uid) {
        db.collection("citas")
                .whereEqualTo("uidCliente", uid)
                .orderBy("fecha", Query.Direction.ASCENDING)
                .orderBy("hora",  Query.Direction.ASCENDING)
                .limit(20) // trae unas cuantas y filtramos en cliente
                .get()
                .addOnSuccessListener(snap -> {
                    DocumentSnapshot futura = null;
                    for (DocumentSnapshot d : snap) {
                        String f = d.getString("fecha");
                        String h = d.getString("hora");
                        if (compareWithNowLima(f, h) >= 0) { futura = d; break; }
                    }
                    if (futura != null) renderBannerConCita(futura);
                    else mostrarSinProximaCita();
                })
                .addOnFailureListener(e -> mostrarSinProximaCita());
    }

    private void renderBannerConCita(DocumentSnapshot d) {
        proximaCitaId = d.getId();

        String servicioId = d.getString("servicioId");
        String staffId    = d.getString("staffId");
        String fecha      = d.getString("fecha");  // "YYYY-MM-DD"
        String hora       = d.getString("hora");   // "HH:mm"

        tvNextTitle.setText("Tu próxima cita"); // ya lo tienes en el XML, lo reafirmamos

        // Texto base: Fecha • Hora
        String fechaBonita = formatFechaHoraBonita(fecha, hora);

        // Cargamos nombre de servicio y del staff (si existen)
        final String[] nombreServicio = { null };
        final String[] nombreStaff    = { null };

        List<Runnable> rendersPendientes = new ArrayList<>();

        if (servicioId != null) {
            rendersPendientes.add(() ->
                    db.collection("servicios").document(servicioId).get()
                            .addOnSuccessListener(sd -> {
                                nombreServicio[0] = sd.getString("nombre");
                                actualizarDetalle(fechaBonita, nombreServicio[0], nombreStaff[0]);
                            })
            );
        }
        if (staffId != null) {
            rendersPendientes.add(() ->
                    db.collection("staff").document(staffId).get()
                            .addOnSuccessListener(st -> {
                                nombreStaff[0] = st.getString("nombre");
                                actualizarDetalle(fechaBonita, nombreServicio[0], nombreStaff[0]);
                            })
            );
        }

        // Primer render (sin esperar a nombres)
        actualizarDetalle(fechaBonita, null, null);

        // Dispara fetchs
        for (Runnable r : rendersPendientes) r.run();
    }

    private void actualizarDetalle(String fechaBonita, @Nullable String serv, @Nullable String staff) {
        // Ejemplo: "Mar 07 Oct • 10:30\nFacial Premium • Con Ana"
        StringBuilder sb = new StringBuilder();
        sb.append(fechaBonita);
        if (serv != null && !serv.isEmpty()) {
            sb.append("\n").append(serv);
            if (staff != null && !staff.isEmpty()) {
                sb.append(" • Con ").append(staff);
            }
        }
        tvNextDetail.setText(sb.toString());
    }

    private void mostrarSinProximaCita() {
        proximaCitaId = null;
        tvNextTitle.setText("Tu próxima cita");
        tvNextDetail.setText("Aún no tienes una cita programada.");
    }

    // ================= Helpers de tiempo (America/Lima) =================

    private int compareWithNowLima(String fecha, String hora) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            fmt.setTimeZone(TimeZone.getTimeZone("America/Lima"));
            Date dt = fmt.parse(fecha + " " + hora);
            Calendar now = Calendar.getInstance(TimeZone.getTimeZone("America/Lima"));
            return dt.compareTo(now.getTime()); // <0 pasada, >=0 futura
        } catch (Exception e) { return 0; }
    }

    private String formatFechaHoraBonita(String fecha, String hora) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            in.setTimeZone(TimeZone.getTimeZone("America/Lima"));
            Date d = in.parse(fecha + " " + hora);
            SimpleDateFormat out = new SimpleDateFormat("EEE dd MMM • HH:mm", new Locale("es","PE"));
            out.setTimeZone(TimeZone.getTimeZone("America/Lima"));
            return out.format(d);
        } catch (Exception e) {
            return (fecha != null ? fecha : "") + " • " + (hora != null ? hora : "");
        }
    }
}
