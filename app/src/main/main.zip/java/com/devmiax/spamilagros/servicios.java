package com.devmiax.spamilagros;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.devmiax.spamilagros.Adapter.ServiciosAdapter;
import com.devmiax.spamilagros.R;
import com.devmiax.spamilagros.models.ServicioCliente;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class servicios extends AppCompatActivity {

    private MaterialToolbar toolbar;
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipe;
    private androidx.recyclerview.widget.RecyclerView rv;
    private LinearProgressIndicator progress;
    private TextInputEditText editBuscar;
    private ChipGroup chipGroup;
    private com.google.android.material.textview.MaterialTextView tvEmpty;

    private FirebaseFirestore db;
    private ListenerRegistration liveListener;

    private ServiciosAdapter adapter;
    private final List<ServicioCliente> loaded = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicios);

        db = FirebaseFirestore.getInstance();

        toolbar = findViewById(R.id.toolbarServicios);
        swipe   = findViewById(R.id.swipeServicios);
        rv      = findViewById(R.id.rvServicios);
        progress= findViewById(R.id.progressServicios);
        editBuscar = findViewById(R.id.editBuscar);
        chipGroup  = findViewById(R.id.chipGroupCategorias);
        tvEmpty    = findViewById(R.id.tvEmptyState);

        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ServiciosAdapter(this);
        rv.setAdapter(adapter);

        adapter.setOnEmptyStateChanged(empty -> tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE));

        swipe.setOnRefreshListener(this::loadOnce);

        // Búsqueda en vivo
        editBuscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                adapter.setQuery(s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        attachRealtime(); // o usa loadOnce() si prefieres sin tiempo real
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (liveListener != null) liveListener.remove();
    }

    private void attachRealtime() {
        progress.setVisibility(View.VISIBLE);
        liveListener = db.collection("servicios")
                .orderBy("nombre", Query.Direction.ASCENDING)
                .addSnapshotListener((snap, e) -> {
                    progress.setVisibility(View.GONE);
                    swipe.setRefreshing(false);
                    if (e != null || snap == null) {
                        adapter.setItems(new ArrayList<>());
                        return;
                    }
                    loaded.clear();
                    snap.getDocuments().forEach(d -> {
                        ServicioCliente s = ServicioCliente.from(d);
                        if (s.activo == null || s.activo) loaded.add(s); // solo activos
                    });
                    adapter.setItems(loaded);
                    buildCategoryChips(loaded);
                });
    }

    private void loadOnce() {
        db.collection("servicios")
                .orderBy("nombre", Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snap -> {
                    loaded.clear();
                    snap.getDocuments().forEach(d -> {
                        ServicioCliente s = ServicioCliente.from(d);
                        if (s.activo == null || s.activo) loaded.add(s);
                    });
                    adapter.setItems(loaded);
                    buildCategoryChips(loaded);
                    swipe.setRefreshing(false);
                })
                .addOnFailureListener(e -> swipe.setRefreshing(false));
    }

    private void buildCategoryChips(List<ServicioCliente> list) {
        chipGroup.removeAllViews();

        // “Todos”
        Chip chipAll = makeChip("Todos", true);
        chipAll.setOnClickListener(v -> adapter.setCategory(null));
        chipGroup.addView(chipAll);

        // Únicas categorías (orden de aparición)
        Set<String> cats = new LinkedHashSet<>();
        for (ServicioCliente s : list) if (s.categoria != null && !s.categoria.isEmpty()) cats.add(s.categoria);

        for (String cat : cats) {
            Chip ch = makeChip(cat, false);
            ch.setOnClickListener(v -> adapter.setCategory(cat));
            chipGroup.addView(ch);
        }
    }

    private Chip makeChip(String text, boolean checked) {
        Chip chip = new Chip(this, null, com.google.android.material.R.style.Widget_Material3_Chip_Filter);
        chip.setText(text);
        chip.setCheckable(true);
        chip.setChecked(checked);
       //chip.setChipMinHeightResource(R.dimen.m3_chip_height); // opcional
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(8), 0);
        chip.setLayoutParams(lp);
        return chip;
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}