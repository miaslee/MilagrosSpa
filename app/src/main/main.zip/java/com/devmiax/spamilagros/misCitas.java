package com.devmiax.spamilagros;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.devmiax.spamilagros.Adapter.CitasAdapter;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.devmiax.spamilagros.R;
import com.devmiax.spamilagros.models.Cita;

import java.util.*;
import java.util.stream.Collectors;

public class misCitas extends AppCompatActivity {

    private MaterialToolbar toolbar;
    private TabLayout tabLayout;
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipe;
    private androidx.recyclerview.widget.RecyclerView rv;
    private LinearLayout emptyContainer;
    private MaterialTextView tvEmptyTitle, tvEmptySub;
    private View btnIrAgendar;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private final List<Cita> todas = new ArrayList<>();
    private final Map<String, CitasAdapter.ServicioLite> servicios = new HashMap<>();
    private CitasAdapter adapter;

    private enum Tab { PROXIMAS, PASADAS }
    private Tab currentTab = Tab.PROXIMAS;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_citas); // :contentReference[oaicite:4]{index=4}

        toolbar        = findViewById(R.id.toolbarMyAppointments);
        tabLayout      = findViewById(R.id.tabLayoutMisCitas);
        swipe          = findViewById(R.id.swipeAppointments);
        rv             = findViewById(R.id.rvAppointments);
        emptyContainer = findViewById(R.id.emptyStateContainer);
        tvEmptyTitle   = findViewById(R.id.tvEmptyTitle);
        tvEmptySub     = findViewById(R.id.tvEmptySub);
        btnIrAgendar   = findViewById(R.id.btnIrAgendar);

        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CitasAdapter(servicios);
        rv.setAdapter(adapter);

        adapter.setOnCitaClick(c -> {
            Intent i = new Intent(this, DetalleCita.class);
            i.putExtra("citaId", c.id);
            startActivity(i);
        });

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                currentTab = (tab.getPosition()==0) ? Tab.PROXIMAS : Tab.PASADAS;
                aplicarFiltroYMostrar();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        swipe.setOnRefreshListener(this::cargarCitas);

        btnIrAgendar.setOnClickListener(v -> {
            // Abre tu flujo de Servicios → Agenda
            startActivity(new Intent(this, servicios.class));
        });

        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        cargarCitas(); // primera carga
    }

    private void cargarCitas() {
        swipe.setRefreshing(true);
        var user = auth.getCurrentUser();
        if (user == null) { swipe.setRefreshing(false); mostrarVacio(true); return; }

        db.collection("citas")
                .whereEqualTo("uidCliente", user.getUid())
                .orderBy("fecha", Query.Direction.ASCENDING)
                .orderBy("hora",  Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snap -> {
                    todas.clear();
                    snap.getDocuments().forEach(d -> todas.add(Cita.from(d)));
                    // Prefetch nombres de servicios
                    prefetchServicios(() -> {
                        swipe.setRefreshing(false);
                        aplicarFiltroYMostrar();
                    });
                })
                .addOnFailureListener(e -> {
                    swipe.setRefreshing(false);
                    mostrarVacio(true);
                });
    }

    private void aplicarFiltroYMostrar() {
        List<Cita> lista = new ArrayList<>();
        for (Cita c : todas) {
            int cmp = compareWithNow(c.fecha, c.hora);
            if (currentTab == Tab.PROXIMAS && cmp >= 0) lista.add(c);
            if (currentTab == Tab.PASADAS  && cmp <  0) lista.add(c);
        }
        adapter.setItems(lista);
        mostrarVacio(lista.isEmpty());
    }

    private void mostrarVacio(boolean empty) {
        emptyContainer.setVisibility(empty ? View.VISIBLE : View.GONE);
        rv.setVisibility(empty ? View.GONE : View.VISIBLE);
        if (currentTab == Tab.PROXIMAS) {
            tvEmptyTitle.setText("No tienes citas próximas");
            tvEmptySub.setText("Cuando reserves, aparecerán aquí.");
        } else {
            tvEmptyTitle.setText("No tienes citas pasadas");
            tvEmptySub.setText("Tus citas completadas o antiguas aparecerán aquí.");
        }
    }

    // ----------- Servicios (prefetch nombre/duración/precio) -----------
    private void prefetchServicios(Runnable then) {
        Set<String> ids = new HashSet<>();
        for (Cita c : todas) if (c.servicioId != null && !servicios.containsKey(c.servicioId)) ids.add(c.servicioId);
        if (ids.isEmpty()) { then.run(); return; }

        // whereIn admite hasta 10; si hay más, hacemos lotes
        List<String> list = new ArrayList<>(ids);
        final int[] pending = { (int) Math.ceil(list.size() / 10.0) };
        if (pending[0] == 0) pending[0] = 1;

        for (int i = 0; i < list.size(); i += 10) {
            List<String> slice = list.subList(i, Math.min(i+10, list.size()));
            db.collection("servicios")
                    .whereIn(FieldPath.documentId(), slice)
                    .get()
                    .addOnSuccessListener(snap -> {
                        snap.getDocuments().forEach(d -> {
                            String id = d.getId();
                            String nombre = d.getString("nombre");
                            Integer dur = d.getLong("duracionMin") != null ? d.getLong("duracionMin").intValue() : null;
                            Double precio = d.getDouble("precio");
                            servicios.put(id, new CitasAdapter.ServicioLite(nombre, dur, precio));
                        });
                        if (--pending[0] == 0) then.run();
                    })
                    .addOnFailureListener(e -> {
                        if (--pending[0] == 0) then.run();
                    });
        }
    }

    // ----------- Comparación fecha/hora vs ahora (America/Lima) -----------
    private int compareWithNow(String fecha, String hora) {
        try {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            fmt.setTimeZone(java.util.TimeZone.getTimeZone("America/Lima"));
            java.util.Date dt = fmt.parse(fecha + " " + hora);

            Calendar now = Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Lima"));
            return dt.compareTo(now.getTime()); // <0 pasada, >=0 próxima
        } catch (Exception e) { return 0; }
    }
}
